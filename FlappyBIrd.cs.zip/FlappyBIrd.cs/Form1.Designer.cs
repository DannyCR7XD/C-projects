﻿namespace FlappyBIrd.cs
{
    partial class FlappyBIrd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ScoreKeeper = new System.Windows.Forms.Label();
            this.Timer = new System.Windows.Forms.Timer(this.components);
            this.PipeTop = new System.Windows.Forms.PictureBox();
            this.JumpyBird = new System.Windows.Forms.PictureBox();
            this.Ground = new System.Windows.Forms.PictureBox();
            this.PipeBottom = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PipeTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.JumpyBird)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ground)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PipeBottom)).BeginInit();
            this.SuspendLayout();
            // 
            // ScoreKeeper
            // 
            this.ScoreKeeper.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.ScoreKeeper.Font = new System.Drawing.Font("Unispace", 36F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScoreKeeper.Location = new System.Drawing.Point(280, 802);
            this.ScoreKeeper.Name = "ScoreKeeper";
            this.ScoreKeeper.Size = new System.Drawing.Size(682, 100);
            this.ScoreKeeper.TabIndex = 0;
            this.ScoreKeeper.Text = "Score: ";
            this.ScoreKeeper.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Timer
            // 
            this.Timer.Enabled = true;
            this.Timer.Interval = 20;
            this.Timer.Tick += new System.EventHandler(this.TimerEvent);
            // 
            // PipeTop
            // 
            this.PipeTop.Image = global::FlappyBIrd.cs.Properties.Resources.pipedown;
            this.PipeTop.Location = new System.Drawing.Point(958, -23);
            this.PipeTop.Name = "PipeTop";
            this.PipeTop.Size = new System.Drawing.Size(150, 300);
            this.PipeTop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PipeTop.TabIndex = 1;
            this.PipeTop.TabStop = false;
            this.PipeTop.Click += new System.EventHandler(this.PipeTop_Click);
            // 
            // JumpyBird
            // 
            this.JumpyBird.Image = global::FlappyBIrd.cs.Properties.Resources.bird;
            this.JumpyBird.Location = new System.Drawing.Point(53, 52);
            this.JumpyBird.Name = "JumpyBird";
            this.JumpyBird.Size = new System.Drawing.Size(120, 60);
            this.JumpyBird.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.JumpyBird.TabIndex = 2;
            this.JumpyBird.TabStop = false;
            // 
            // Ground
            // 
            this.Ground.Image = global::FlappyBIrd.cs.Properties.Resources.ground;
            this.Ground.Location = new System.Drawing.Point(-5, 757);
            this.Ground.Name = "Ground";
            this.Ground.Size = new System.Drawing.Size(1193, 184);
            this.Ground.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Ground.TabIndex = 3;
            this.Ground.TabStop = false;
            // 
            // PipeBottom
            // 
            this.PipeBottom.Image = global::FlappyBIrd.cs.Properties.Resources.pipe;
            this.PipeBottom.Location = new System.Drawing.Point(958, 554);
            this.PipeBottom.Name = "PipeBottom";
            this.PipeBottom.Size = new System.Drawing.Size(150, 300);
            this.PipeBottom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PipeBottom.TabIndex = 4;
            this.PipeBottom.TabStop = false;
            this.PipeBottom.Click += new System.EventHandler(this.PipeBottom_Click);
            // 
            // FlappyBIrd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(23F, 44F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1184, 911);
            this.Controls.Add(this.JumpyBird);
            this.Controls.Add(this.ScoreKeeper);
            this.Controls.Add(this.Ground);
            this.Controls.Add(this.PipeTop);
            this.Controls.Add(this.PipeBottom);
            this.Font = new System.Drawing.Font("Unispace", 27.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(12, 10, 12, 10);
            this.Name = "FlappyBIrd";
            this.Text = "FlappyBirdGame";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gamekeyisDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.gamekeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.PipeTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.JumpyBird)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ground)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PipeBottom)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label ScoreKeeper;
        private System.Windows.Forms.Timer Timer;
        private System.Windows.Forms.PictureBox PipeTop;
        private System.Windows.Forms.PictureBox JumpyBird;
        private System.Windows.Forms.PictureBox Ground;
        private System.Windows.Forms.PictureBox PipeBottom;
    }
}

