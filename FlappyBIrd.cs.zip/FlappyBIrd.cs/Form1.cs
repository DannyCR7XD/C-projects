﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyBIrd.cs
{
    public partial class FlappyBIrd : Form
    {

        int pipeSpeed = 8;
        int gravity = 5;
        int score = 0;

        public FlappyBIrd()
        {
            InitializeComponent();
        }

        private void TimerEvent(object sender, EventArgs e)
        {
            JumpyBird.Top += gravity;
            PipeBottom.Left -= pipeSpeed;
            PipeTop.Left -= pipeSpeed;
            ScoreKeeper.Text = "Score: " + score;

            if (PipeBottom.Left < -150)
            {
                PipeBottom.Left = 800;
                score++;
            }
            if (PipeTop.Left < -180) {

                PipeTop.Left = 950;
                score++;
            }

            if (JumpyBird.Bounds.IntersectsWith(PipeBottom.Bounds) ||
                JumpyBird.Bounds.IntersectsWith(PipeTop.Bounds) ||
                JumpyBird.Bounds.IntersectsWith(Ground.Bounds) ||
                JumpyBird.Top < -25
                ) 
            { 
                EndGame();
            }

            if (score > 10)
            {
                pipeSpeed = 15;
            }
            if (score > 30)
            {
                pipeSpeed = 25;
            }
            if (score > 50)
            {
                pipeSpeed = 40;
            }
            if (score > 80)
            {
                pipeSpeed = 75;
            }
        }
        private void gamekeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = 10;
            }
        }

        private void gamekeyisDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = -15;
            }
        }

        private void EndGame() { 
        Timer.Stop();
            ScoreKeeper.Text += " Game Over!!";
        }
        
        private void PipeTop_Click(object sender, EventArgs e)
        {

        }

        private void PipeBottom_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        
    }
}
